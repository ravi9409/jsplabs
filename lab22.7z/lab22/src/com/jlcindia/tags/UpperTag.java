package com.jlcindia.tags;

import java.io.Writer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.BodyTagSupport;
import javax.servlet.jsp.tagext.TagSupport;

public class UpperTag extends BodyTagSupport {


	
	@Override
	public int doStartTag() throws JspException {
		return EVAL_BODY_BUFFERED;
	
	}
	
	@Override
	public int doEndTag() throws JspException {
		
		String string=getBodyContent().getString();
		try {
			Writer out=pageContext.getOut();
			out.write(string.toUpperCase());
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
		return EVAL_PAGE;
	}
	
	
}
