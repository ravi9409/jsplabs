package com.jlcindia.ctag;

import java.io.Writer;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.tagext.TagSupport;

public class ShowMessageTag extends TagSupport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String sname;
	private String email;
	
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public int doEngTag() throws JspException
	{
		Writer out =pageContext.getOut();
		try {
			if (sname==null||sname.trim().isEmpty()) {
				out.write("<font color='red'> You have not specified your name</font");
			}else
			{
				out.write("Hi<font color='blue'>"+sname+"</font>");
				if (email==null||email.trim().isEmpty()) {
					out.write("<br/><font color='red'>You have not specified your email>/font>");
				}else {
					out.write("<br/>Your email is <font color='blue'>"+email+"</font>");
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
		
		return super.doEndTag();
	}
	
	
}
